
export const InitialFeedback = {
    firstname: '',
    lastname: '',
    telnum: '',
    email: '',
    agree: false,
    ccontactType: 'Tel.',
    message: ''
}